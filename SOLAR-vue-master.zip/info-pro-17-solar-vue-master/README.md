# Solar frontend

Project description
Web application for manage off-grid solar system where a user can check battery status, charging and/or consumption, battery time left, and location of the solar system (mobile caravan, yacht...). 
